-- VELORA database schema for Supabase
create extension if not exists "pgcrypto";

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  display_name text not null default 'عضو جديد',
  avatar_url text,
  bio text,
  created_at timestamptz not null default now()
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references public.profiles(id) on delete cascade,
  body text not null,
  media_url text,
  likes_count integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.post_likes (
  post_id uuid references public.posts(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(post_id,user_id)
);

create table if not exists public.stories (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references public.profiles(id) on delete cascade,
  body text not null,
  media_url text,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  user_a uuid not null references public.profiles(id) on delete cascade,
  user_b uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(user_a,user_b)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text,
  created_at timestamptz not null default now()
);

create index if not exists stories_expiry_idx on public.stories(expires_at);
create index if not exists posts_created_idx on public.posts(created_at desc);
create index if not exists messages_conversation_idx on public.messages(conversation_id,created_at);

create or replace function public.toggle_like(post_uuid uuid)
returns void language plpgsql security definer set search_path=public as $$
begin
  if exists(select 1 from public.post_likes where post_id=post_uuid and user_id=auth.uid()) then
    delete from public.post_likes where post_id=post_uuid and user_id=auth.uid();
    update public.posts set likes_count=greatest(likes_count-1,0) where id=post_uuid;
  else
    insert into public.post_likes(post_id,user_id) values(post_uuid,auth.uid());
    update public.posts set likes_count=likes_count+1 where id=post_uuid;
  end if;
end $$;

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.post_likes enable row level security;
alter table public.stories enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;

create policy "profiles readable" on public.profiles for select using (true);
create policy "profile own insert" on public.profiles for insert with check (auth.uid()=id);
create policy "profile own update" on public.profiles for update using (auth.uid()=id);

create policy "posts readable" on public.posts for select using (true);
create policy "posts own insert" on public.posts for insert with check (auth.uid()=author_id);
create policy "posts own update" on public.posts for update using (auth.uid()=author_id);
create policy "posts own delete" on public.posts for delete using (auth.uid()=author_id);

create policy "likes readable" on public.post_likes for select using (true);
create policy "likes own" on public.post_likes for insert with check (auth.uid()=user_id);
create policy "likes own delete" on public.post_likes for delete using (auth.uid()=user_id);

create policy "stories readable" on public.stories for select using (expires_at>now());
create policy "stories own insert" on public.stories for insert with check (auth.uid()=author_id);
create policy "stories own delete" on public.stories for delete using (auth.uid()=author_id);

create policy "conversation members read" on public.conversations for select using (auth.uid()=user_a or auth.uid()=user_b);
create policy "conversation members insert" on public.conversations for insert with check (auth.uid()=user_a or auth.uid()=user_b);

create policy "messages members read" on public.messages for select using (
 exists(select 1 from public.conversations c where c.id=conversation_id and (c.user_a=auth.uid() or c.user_b=auth.uid()))
);
create policy "messages own insert" on public.messages for insert with check (
 auth.uid()=sender_id and exists(select 1 from public.conversations c where c.id=conversation_id and (c.user_a=auth.uid() or c.user_b=auth.uid()))
);

-- Enable realtime for chat/call signaling later:
alter publication supabase_realtime add table public.messages;
alter publication supabase_realtime add table public.conversations;

-- Remove expired stories automatically from reads; optional scheduled cleanup can delete old rows.
